export class Planet {
    id: number;
    name: string;
    numberOfMoons: number;
}