import { Planet } from './planet';

describe('Planet', () => {
  it('should create an instance', () => {
    expect(new Planet()).toBeTruthy();
  });
});
