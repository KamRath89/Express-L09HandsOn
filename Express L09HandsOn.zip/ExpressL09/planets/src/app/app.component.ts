import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular 2 Planets'; //<--- Change title
  staticPath: string = 'http://localhost:3001/staticPlanets'; //<--- set @input property
  starTrekPath: string = 'http://localhost:3001/starTrekPlanets';
}