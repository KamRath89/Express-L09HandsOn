module.exports.starTerkPlanet = [
    {
      name: "Q'onoS",
      numberOfMoons: 1,
    },
    {
      name: "Vulcan",
      numberOfMoons: 0,
    },
    {
      name: "Earth",
      numberOfMoons: 1,
    },
    {
      name: "Rator III",
      numberOfMoons: 0,
    }
  ];